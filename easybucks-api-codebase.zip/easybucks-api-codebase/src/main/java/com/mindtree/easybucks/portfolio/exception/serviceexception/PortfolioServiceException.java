package com.mindtree.easybucks.portfolio.exception.serviceexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class PortfolioServiceException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public PortfolioServiceException() {
		super();
	}

	public PortfolioServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
