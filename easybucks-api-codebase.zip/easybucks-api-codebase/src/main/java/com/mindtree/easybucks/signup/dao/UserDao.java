package com.mindtree.easybucks.signup.dao;

import java.util.List;


import com.mindtree.easybucks.signup.entity.AdvisorRequests;
import com.mindtree.easybucks.signup.entity.User;

public interface UserDao {
	public boolean adduser(User user);
	public List<User> getUser();
	public User getUserById(int userId);
	public List<String> getEmail();
	public boolean deleteUser(int userId);
	public boolean addAdvisorRequest(AdvisorRequests advisorRequests);
	public AdvisorRequests updateAdvisorRequest(AdvisorRequests advisorRequests);
	public boolean deleteAdvisorRequest(int advisorRequestId);
	public List<AdvisorRequests>  getALLAdvisorRequests();
}
