package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.PortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.PortfolioService;

@Service
public class PortfolioServiceImpl implements PortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;

	public boolean addToPortfolio(Portfolio portfolio) throws PortfolioServiceException {
		try{
			return portfolioDao.addToPortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new PortfolioServiceException("Error in adding portfolio in service  ", e.getCause());
		}
	}

	public boolean deletePortfolio(Portfolio portfolio) throws PortfolioServiceException {
		try{
			return portfolioDao.deletePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new PortfolioServiceException("Error in deleting portfolio in service", e.getCause());
		}
	}

	public List<Portfolio> getAllPortfolio() throws PortfolioServiceException {
		try{
			return portfolioDao.getAllPortfolio();
		}
		catch(PortfolioDaoException e){
			throw new PortfolioServiceException("Error getting portfolio in service", e.getCause());
		}
	}

	public Portfolio getPortfolioByUserId(int userId) throws PortfolioServiceException {
		try{
			return portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new PortfolioServiceException("Error getting potfolio by userId in service", e.getCause());
		}
	}

	public boolean updateToPortfolio(Portfolio portfolio) throws PortfolioServiceException {
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new PortfolioServiceException("Error in updating portfolio in service", e.getCause());
		}
	}
	
}
