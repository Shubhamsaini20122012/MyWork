package com.mindtree.easybucks.signup.dao.DaoImp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.mindtree.easybucks.signup.dao.UserDao;
import com.mindtree.easybucks.signup.entity.AdvisorRequests;
import com.mindtree.easybucks.signup.entity.User;

@Repository
@Transactional("transactionManager")
public class UserDaoImpl implements UserDao {
	
	private static final Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	public void closeSession() {
		this.sessionFactory.close();
	}
	
	public boolean adduser(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		return true;
	}

	public List<User> getUser() {
		List<User> list = new ArrayList<User>();
		list = sessionFactory.getCurrentSession().createQuery("from User").list();
		return list;
	}
	@SuppressWarnings("unchecked")
	public List<String> getEmail(){
		List<String> list = new ArrayList<String>();
		list = sessionFactory.getCurrentSession().createQuery("select userEmail from User").list();
		return list;
	}

	public User getUserById(int userId) {
			User user = new User() ;
			user = sessionFactory.getCurrentSession().get(User.class, userId);
			return user ;
	}
	
	public boolean deleteUser(int userId)
	{
		Integer id=Integer.valueOf(userId);
		User user=sessionFactory.getCurrentSession().get(User.class, id);
		sessionFactory.getCurrentSession().delete(user);
		return true;
	}
	
	public boolean addAdvisorRequest(AdvisorRequests advisorRequests)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(advisorRequests);
		return true;
	}
	
	public AdvisorRequests updateAdvisorRequest(AdvisorRequests advisorRequests)
	{
		AdvisorRequests advisorRequests1=null;
		sessionFactory.getCurrentSession().update(advisorRequests);
		Integer id=Integer.valueOf(advisorRequests.getAdvisorRequestId());
		advisorRequests1 = sessionFactory.getCurrentSession().get(AdvisorRequests.class, id);
		return advisorRequests1;
	}
	
	public boolean deleteAdvisorRequest(int advisorRequestId)
	{
		Integer id=Integer.valueOf(advisorRequestId);
		AdvisorRequests advisorRequests=sessionFactory.getCurrentSession().get(AdvisorRequests.class, id);
		sessionFactory.getCurrentSession().delete(advisorRequests);
		return true;
	}
	
	public List<AdvisorRequests>  getALLAdvisorRequests()
	{
		List<AdvisorRequests> advisorRequests = sessionFactory.getCurrentSession().createQuery("from AdvisorRequests").list();
		if(null != advisorRequests) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return advisorRequests;
	}
}
