package com.mindtree.easybucks.watchlist.services.bankingservice;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

public interface BankingWatchlistService {
	
	public boolean addToBankingWatchlist(User user,Banking bank) throws WatchlistServiceException;
	public boolean deleteFromBankingWatchlist(User user,Banking bank) throws WatchlistServiceException;
	public List<Banking> getBankingWatchlistByUser(User user) throws WatchlistServiceException;
	public Set<Banking> getBankingWatchlistByUser1(User user) throws WatchlistServiceException;

}
