package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.List;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.MFPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.MFPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.MFPortfolioService;

public class MFPortfolioServiceImpl implements MFPortfolioService {
	
	private PortfolioDao portfolioDao;

	public boolean addMFPortfolioByUserId(MFPortfolio mfPortfolio, int userId) throws MFPortfolioServiceException {
		
		Portfolio portfolio;
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in getting portfolio by userId in MF service", e.getCause());
		}
		
		List<MFPortfolio> mfPortList = portfolio.getMfPort();
		mfPortList.add(mfPortfolio);
		portfolio.setMfPort(mfPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in updating portfolio in MF Service", e.getCause());
		}
	}

	public boolean deleteMFPortfolioByUserId(MFPortfolio mfPortfolio, int userId) throws MFPortfolioServiceException {
		
		Portfolio portfolio;
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in getting portfolio in MF Service", e.getCause());
		}
		
		List<MFPortfolio> mfPortList = portfolio.getMfPort();
		mfPortList.remove(mfPortfolio);
		portfolio.setMfPort(mfPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in updating Portfolio", e.getCause());
		}
		
	}

	public List<MFPortfolio> getMFPortfolioByUserId(int userId) throws MFPortfolioServiceException {
		try{
			Portfolio portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getMfPort();
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException ("Error in getting portfolio by id in MF Service",e.getCause());
		}
	}

}
