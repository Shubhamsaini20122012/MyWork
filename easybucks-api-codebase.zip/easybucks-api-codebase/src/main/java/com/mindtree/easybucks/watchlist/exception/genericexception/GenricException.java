package com.mindtree.easybucks.watchlist.exception.genericexception;

import com.mindtree.easybucks.watchlist.exception.WatchlistException;

public class GenricException extends WatchlistException {

	private static final long serialVersionUID = 1L;

	public GenricException() {
		super();
	}

	public GenricException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	

}
