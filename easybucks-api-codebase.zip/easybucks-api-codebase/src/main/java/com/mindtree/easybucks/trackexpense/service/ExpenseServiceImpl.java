package com.mindtree.easybucks.trackexpense.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.easybucks.trackexpense.dao.ExpenseDao;
import com.mindtree.easybucks.trackexpense.entities.Expense;
import com.mindtree.easybucks.trackexpense.exception.daoexception.ExpenseDaoException;
import com.mindtree.easybucks.trackexpense.exception.serviceexception.ExpenseServiceException;

@Service
public class ExpenseServiceImpl implements ExpenseService {
	
	@Autowired
	private ExpenseDao expenseDao;

	public boolean addExpense(Expense expense) throws ExpenseServiceException {
		try {
			return this.expenseDao.addExpense(expense);
		} catch (ExpenseDaoException e) {
			throw new ExpenseServiceException("unable to add in service",e);
			
		}
	}

	public boolean deleteExpense(Expense expense) throws ExpenseServiceException {
		try {
			return this.expenseDao.deleteExpense(expense);
		} catch (ExpenseDaoException e) {
			throw new ExpenseServiceException("unable to delete in service",e);
		}
	}

	public Expense updateExpense(Expense expense) throws ExpenseServiceException {
		try {
			return this.expenseDao.updateExpense(expense);
		} catch (ExpenseDaoException e) {
			throw new ExpenseServiceException("unable to update in service",e);
		}
	}

	public Expense getExpenseById(int id) throws ExpenseServiceException {
		try {
			return this.expenseDao.getExpenseById(id);
		} catch (ExpenseDaoException e) {
			throw new ExpenseServiceException("unable to get in service",e);
		}
	}

	public List<Expense> getAllExpenses(int userId) throws ExpenseServiceException {
		try {
			return this.expenseDao.getAllExpenses(userId);
		} catch (ExpenseDaoException e) {
			throw new ExpenseServiceException("unable to get in service",e);
		}
	}

	
}
