package com.mindtree.easybucks.products.dao;

import java.util.List;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;

public interface StocksDao {
	
	String addStocks(Stocks stocks) throws ProductsDaoException ;
	List<Stocks> getAllStocks() throws ProductsDaoException ;
	Stocks getStocks(int id) throws ProductsDaoException ;
	String deleteStocks(int id) throws ProductsDaoException ;
}
