package com.mindtree.easybucks.seekassistance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.seekassistance.dto.BookAppointmentDTO;
import com.mindtree.easybucks.seekassistance.dto.BookAppointmentUpdateDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.seekassistance.services.SeekAssistanceService;
import com.mindtree.easybucks.signup.entity.User;





@RestController
@RequestMapping(value="/seekassistance")
public class SeekAssistanceController 
{
	@Autowired
	private SeekAssistanceService seekAssistanceService;
	
	@Qualifier(value="seekAssistanceService")
	public void setSeekAssistanceService(SeekAssistanceService seekAssistanceService)
	{
		this.seekAssistanceService=seekAssistanceService;
	}
	
	@RequestMapping(value="/alldetails", method = RequestMethod.GET, produces="application/json")
	public List<SeekAssistance>  getAllSeekAssistanceDetails() {
		return this.seekAssistanceService.getALLSeekAssistanceDetails();
	}
	
	@RequestMapping(value="/addAssistance", method = RequestMethod.POST, consumes="application/json")
	public boolean addSeekAssistance(@RequestBody SeekAssistanceDTO seekAssistancedto) {
		
		return this.seekAssistanceService.addSeekAssistance(seekAssistancedto);
	}
	
	@RequestMapping(value="/updateAssistance", method = RequestMethod.PUT, consumes="application/json")
	public SeekAssistance updateSeekAssistanceDetail(@RequestBody SeekAssistanceUpdateDTO seekAssistanceUpdatedto) {
		
		return this.seekAssistanceService.updateSeekAssistanceDetail(seekAssistanceUpdatedto);
	}
	
	@RequestMapping(value="/deleteAssistance/{seekAssistanceId}", method = RequestMethod.DELETE)
	public boolean deleteSeekAssistance(@PathVariable("seekAssistanceId") int seekAssistanceId) {
		return this.seekAssistanceService.deleteSeekAssistance(seekAssistanceId);
	}
	
	@RequestMapping(value="/allusers", method = RequestMethod.GET, produces="application/json")
	public List<User>  getAllUsers() {
		return this.seekAssistanceService.getALLUsersDetails();
	}
	
	@RequestMapping(value="/addBookAppointment", method = RequestMethod.POST, consumes="application/json")
	public boolean addBookAppointment(@RequestBody BookAppointmentDTO bookAppointmentdto)
	{
		System.out.println(bookAppointmentdto);
		return this.seekAssistanceService.addBookAppointment(bookAppointmentdto);
	}
	
	@RequestMapping(value="/updateBookAppointment", method = RequestMethod.PUT, consumes="application/json")
	public BookAppointment updateBookAppointment(@RequestBody BookAppointmentUpdateDTO bookAppointmentUpdatedto)
	{
		return this.seekAssistanceService.updateBookAppointment(bookAppointmentUpdatedto);
	}
	
	@RequestMapping(value="/allAppointments", method = RequestMethod.GET, produces="application/json")
	public List<BookAppointment>  getAllAppointmentDetails() {
		return this.seekAssistanceService.getALLAppointmentDetails();
	}
	
	@RequestMapping(value="/deleteAppointment/{bookAppointmentId}", method = RequestMethod.DELETE)
	public boolean deleteBookAppointment(@PathVariable("bookAppointmentId") int bookAppointmentId) {
		return this.seekAssistanceService.deleteBookAppointment(bookAppointmentId);
	}
	
}
