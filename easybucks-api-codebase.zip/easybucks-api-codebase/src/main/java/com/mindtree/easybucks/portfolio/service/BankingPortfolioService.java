package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BankingPortfolioServiceException;

public interface BankingPortfolioService {
	
	public boolean addBankingPortfolioByUserId(BankingPortfolio bankingPortfolio, int userId) throws BankingPortfolioServiceException;
	
	public boolean deleteBankingPortfolioByUserId(BankingPortfolio bankingPortfolio, int userId) throws BankingPortfolioServiceException;
	
	public List<BankingPortfolio> getPortfolioByUserId(int userId) throws BankingPortfolioServiceException;

}
