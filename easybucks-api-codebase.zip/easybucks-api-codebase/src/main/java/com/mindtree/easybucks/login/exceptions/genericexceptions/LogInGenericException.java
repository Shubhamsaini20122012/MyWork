package com.mindtree.easybucks.login.exceptions.genericexceptions;

import com.mindtree.easybucks.login.exceptions.LoginException;

public class LogInGenericException extends LoginException {

	private static final long serialVersionUID = 1L;

	public LogInGenericException() {
		super();
	}

	public LogInGenericException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
