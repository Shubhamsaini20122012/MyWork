package com.mindtree.easybucks.trackexpense.exception.serviceexception;

import com.mindtree.easybucks.trackexpense.exception.ExpenseException;

public class ExpenseServiceException extends ExpenseException{

	private static final long serialVersionUID = 1L;

	public ExpenseServiceException() {
		super();
	}

	public ExpenseServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
}
