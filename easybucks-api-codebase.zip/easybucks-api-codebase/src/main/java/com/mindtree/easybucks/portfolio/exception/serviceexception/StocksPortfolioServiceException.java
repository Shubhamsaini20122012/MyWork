package com.mindtree.easybucks.portfolio.exception.serviceexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class StocksPortfolioServiceException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public StocksPortfolioServiceException() {
		super();
	}

	public StocksPortfolioServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
