package com.mindtree.easybucks.profile.dao;

import com.mindtree.easybucks.signup.entity.User;

public interface ProfileDao {

	User getProfile(int userId);

	User updateProfile(User user);
}
