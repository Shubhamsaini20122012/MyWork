package com.mindtree.easybucks.products.dao;

import java.util.List;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;

public interface MutualFundsDao {
	
	String addMutualFunds(MutualFunds mutualFunds) throws ProductsDaoException ;
	List<MutualFunds> getAllFunds() throws ProductsDaoException ;
	MutualFunds getMutualFunds(int id) throws ProductsDaoException ;
	String deleteMutualFunds(int id) throws ProductsDaoException ;
}
