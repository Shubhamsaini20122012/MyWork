package com.mindtree.easybucks.products.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.dao.BullionsDao;
import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BullionsService;

@Service
public class BullionsServiceImpl implements BullionsService{
	
	@Autowired
	private BullionsDao bullionsDao ;

	public void setBullionsDao(BullionsDao bullionsDao) {
		this.bullionsDao = bullionsDao;
	}

	public String addBullions(Bullions bullions) throws ProductsServiceException {
		try {
			return this.bullionsDao.addBullions(bullions);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to add Bullions",e) ;
		}
	}

	public List<Bullions> getAllBullions() throws ProductsServiceException {
		try {
			return this.bullionsDao.getAllBullions();
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch list from Bullions",e) ;
		}
	}
	
	public Bullions getBullions(int id) throws ProductsServiceException {
		try {
			return this.bullionsDao.getBullions(id) ;
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch from Bullions",e) ;
		}
	}
	
	public String deleteBullions(int id) throws ProductsServiceException {
		try {
			return this.bullionsDao.deleteBullions(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to delete Bullions",e) ;
		}
	}
}
