package com.mindtree.easybucks.products.dao;

import java.util.List;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;


public interface BankingDao {
	
	String addBanking(Banking banking) throws ProductsDaoException ;
	List<Banking> getAllBanking() throws ProductsDaoException ;
	Banking getBanking(int id) throws ProductsDaoException ;
	String deleteBanking(int id) throws ProductsDaoException ;
}
