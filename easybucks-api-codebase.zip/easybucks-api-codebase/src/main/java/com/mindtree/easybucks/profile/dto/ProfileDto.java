package com.mindtree.easybucks.profile.dto;

public class ProfileDto 
{
	private int userId;
	private int roleId;
	private String userCity;
	private String userDOB;
	private String userOccupation;
	private long userPhone;
	private double userIncome;
	private String userName;
	private String userEmail;
	private String userPassword;
	
	public ProfileDto() {
		super();
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public int getRoleId() {
		return roleId;
	}
	
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	
	public String getUserCity() {
		return userCity;
	}
	
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	
	public String getUserDOB() {
		return userDOB;
	}
	
	public void setUserDOB(String userDOB) {
		this.userDOB = userDOB;
	}
	
	public String getUserOccupation() {
		return userOccupation;
	}
	
	public void setUserOccupation(String userOccupation) {
		this.userOccupation = userOccupation;
	}
	
	public long getUserPhone() {
		return userPhone;
	}
	
	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}
	
	public double getUserIncome() {
		return userIncome;
	}
	
	public void setUserIncome(double userIncome) {
		this.userIncome = userIncome;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getUserEmail() {
		return userEmail;
	}
	
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
	public String getUserPassword() {
		return userPassword;
	}
	
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
}
