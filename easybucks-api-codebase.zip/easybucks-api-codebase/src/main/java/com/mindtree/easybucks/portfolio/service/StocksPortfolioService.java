package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.StocksPortfolioServiceException;

public interface StocksPortfolioService {
	
	public boolean addStocksPortfolioByUserId(StocksPortfolio stocksPortfolio, int uerId) throws StocksPortfolioServiceException;
	
	public boolean deleteStocksPortfolioByUserId(StocksPortfolio stocksPortfolio, int userId) throws StocksPortfolioServiceException;
	
	public List<StocksPortfolio> getStocksPortfolioByuserId(int userId) throws StocksPortfolioServiceException;

}
