package com.mindtree.easybucks.portfolio.exception;

public class PortfolioException extends Exception {

	private static final long serialVersionUID = 1L;

	public PortfolioException() {
		super();
	}

	public PortfolioException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
