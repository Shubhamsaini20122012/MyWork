package com.mindtree.easybucks.watchlist.dao.mutualfund;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.entities.MutualFundWatchlist;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

@Repository
@Transactional("transactionManager")
public class MutualFundWatchlistDaoImp implements MutualFundWatchlistDao {
	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean addToMutualFundWatchlist(User user, MutualFunds mutualFund) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(MutualFundWatchlist.class, new Integer(user.getUserId()))!=null)
		{	
			if(getMutualFundWatchlistByUser(user).contains(mutualFund)){
			return false;
			}
		}
		else{
			MutualFundWatchlist mutualFundWatchList1 = new MutualFundWatchlist() ;
			mutualFundWatchList1.setUser(user);
			this.sessionFactory.getCurrentSession().save(mutualFundWatchList1) ;
		}
		try {
			List<MutualFunds> mutualFunds = getMutualFundWatchlistByUser(user);
			Set<MutualFunds> mutualFunds1 = new HashSet<MutualFunds>();
			for (MutualFunds m : mutualFunds) {
				mutualFunds1.add(m);
			}
			mutualFunds1.add(mutualFund);
			MutualFundWatchlist mutualFundWatchlist = (MutualFundWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from MutualFundWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			mutualFundWatchlist.setMutualFundsList(mutualFunds1);
			sessionFactory.getCurrentSession().save(mutualFundWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}

	}

	@Transactional
	public boolean deleteFromMutualFundWatchlist(User user, MutualFunds mutualFund) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(MutualFundWatchlist.class, new Integer(user.getUserId()))==null){
			return true ;
		}
		try {
			Set<MutualFunds> mutualFunds = getMutualFundWatchlistByUser1(user);
			mutualFunds.remove(mutualFund);
			MutualFundWatchlist mutualFundWatchlist = (MutualFundWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from MutualFundWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			mutualFundWatchlist.setMutualFundsList(mutualFunds);
			sessionFactory.getCurrentSession().save(mutualFundWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}

	}

	public List<MutualFunds> getMutualFundWatchlistByUser(User user) throws WatchlistDaoException {
		try {
			MutualFundWatchlist mutualFundWatchlist = (MutualFundWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from MutualFundWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			Set<MutualFunds> mutualFunds = mutualFundWatchlist.getMutualFundsList();
			List<MutualFunds> mutualFunds1 = new ArrayList<MutualFunds>();
			for (MutualFunds m : mutualFunds) {
				mutualFunds1.add(m);
			}
			return mutualFunds1;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

	public Set<MutualFunds> getMutualFundWatchlistByUser1(User user) throws WatchlistDaoException {
		try {
			MutualFundWatchlist mutualFundWatchlist = (MutualFundWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from MutualFundWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			return mutualFundWatchlist.getMutualFundsList();
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}
}
