package com.mindtree.easybucks.portfolio.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.mindtree.easybucks.signup.entity.User;

@Entity
@Table(name = "portfolio")
public class Portfolio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "portfolio_id")
	private int portfolioId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name  = "user_id", unique = true)
	private User user;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<BankingPortfolio> bankingPort;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<BullionsPortfolio> bullionsPort;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<StocksPortfolio> stocksPort;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<MFPortfolio> mfPort;

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<BankingPortfolio> getBankingPort() {
		return bankingPort;
	}

	public void setBankingPort(List<BankingPortfolio> bankingPort) {
		this.bankingPort = bankingPort;
	}

	public List<BullionsPortfolio> getBullionsPort() {
		return bullionsPort;
	}

	public void setBullionsPort(List<BullionsPortfolio> bullionsPort) {
		this.bullionsPort = bullionsPort;
	}


	public List<StocksPortfolio> getStocksPort() {
		return stocksPort;
	}

	public void setStocksPort(List<StocksPortfolio> stocksPort) {
		this.stocksPort = stocksPort;
	}

	public List<MFPortfolio> getMfPort() {
		return mfPort;
	}

	public void setMfPort(List<MFPortfolio> mfPort) {
		this.mfPort = mfPort;
	}

	@Override
	public String toString() {
		return "Portfolio [portfolioId=" + portfolioId + ", user=" + user + ", bankingPort=" + bankingPort
				+ ", bullionsPort=" + bullionsPort + ", stocksPort=" + stocksPort + ", mfPort=" + mfPort + "]";
	}

	
}
