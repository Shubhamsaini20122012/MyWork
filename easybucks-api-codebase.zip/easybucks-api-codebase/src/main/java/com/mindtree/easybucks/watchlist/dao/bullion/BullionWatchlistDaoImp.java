package com.mindtree.easybucks.watchlist.dao.bullion;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.entities.BullionWatchlist;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

@Repository
@Transactional("transactionManager")
public class BullionWatchlistDaoImp implements BullionWatchlistDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean addToBullionWatchlist(User user, Bullions bullion) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(BullionWatchlist.class, new Integer(user.getUserId()))!=null)
		{	
			if(getBullionWatchlistByUser(user).contains(bullion)){
			return false;
			}
		}
		else{
			BullionWatchlist bullionWatchList1 = new BullionWatchlist() ;
			bullionWatchList1.setUser(user);
			this.sessionFactory.getCurrentSession().save(bullionWatchList1) ;
		}
		try {
			List<Bullions> bullions = getBullionWatchlistByUser(user);
			Set<Bullions> bullions1 = new HashSet<Bullions>();
			for (Bullions m : bullions) {
				bullions1.add(m);
			}
			bullions1.add(bullion);
			BullionWatchlist bullionWatchlist = (BullionWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from BullionWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			bullionWatchlist.setBullionsList(bullions1);
			sessionFactory.getCurrentSession().save(bullionWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

	public boolean deleteFromBullionWatchlist(User user, Bullions bullion) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(BullionWatchlist.class, new Integer(user.getUserId()))==null){
			return true ;
		}
		try {
			List<Bullions> bullions = getBullionWatchlistByUser(user);
			Set<Bullions> bullions1 = new HashSet<Bullions>();
			for (Bullions m : bullions) {
				bullions1.add(m);
			}
			bullions1.remove(bullion);
			BullionWatchlist bullionWatchlist = (BullionWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from BullionWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			bullionWatchlist.setBullionsList(bullions1);
			sessionFactory.getCurrentSession().save(bullionWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}

	}

	public List<Bullions> getBullionWatchlistByUser(User user) throws WatchlistDaoException {
		try {
			BullionWatchlist bullionWatchlist = (BullionWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from BullionWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			Set<Bullions> bullions = bullionWatchlist.getBullionsList();
			List<Bullions> bullions1 = new ArrayList<Bullions>();
			for (Bullions b : bullions) {
				bullions1.add(b);
			}
			return bullions1;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

	public Set<Bullions> getBullionWatchlistByUser1(User user) throws WatchlistDaoException {
		try {
			BullionWatchlist bullionWatchlist = (BullionWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from bullionWatchlist m where m.user = :user").setParameter("user", user).list()
					.get(0);
			return bullionWatchlist.getBullionsList();
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

}
