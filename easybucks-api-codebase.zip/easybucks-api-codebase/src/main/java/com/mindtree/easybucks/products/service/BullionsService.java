package com.mindtree.easybucks.products.service;

import java.util.List;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;

public interface BullionsService {
	String addBullions(Bullions bullions) throws ProductsServiceException ;
	List<Bullions> getAllBullions() throws ProductsServiceException ;
	Bullions getBullions(int id) throws ProductsServiceException ;
	String deleteBullions(int id) throws ProductsServiceException ;
}
