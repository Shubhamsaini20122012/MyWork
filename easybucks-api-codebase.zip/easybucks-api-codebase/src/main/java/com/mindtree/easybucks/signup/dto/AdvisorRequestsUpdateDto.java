package com.mindtree.easybucks.signup.dto;

public class AdvisorRequestsUpdateDto 
{
	private int advisorRequestId;
	private String email;
	private String status;
	public AdvisorRequestsUpdateDto() {
		super();
		
	}
	public int getAdvisorRequestId() {
		return advisorRequestId;
	}
	public void setAdvisorRequestId(int advisorRequestId) {
		this.advisorRequestId = advisorRequestId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
