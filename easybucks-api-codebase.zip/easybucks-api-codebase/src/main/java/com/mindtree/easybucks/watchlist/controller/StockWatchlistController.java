package com.mindtree.easybucks.watchlist.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.StocksService;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.stockmarketservice.StockWatchlistService;

@CrossOrigin
@RestController
@RequestMapping(value="/watchlist/stocks")
public class StockWatchlistController {
	@Autowired
	private UserService userService;

	@Autowired
	private StockWatchlistService stockWatchlistService; 
	@Autowired
	private StocksService stocksService;
	
	@RequestMapping(value="/all/{id}", method = RequestMethod.GET)
	public List<Stocks>  getAllStocks( @PathVariable("id") Integer id) {
		List<Stocks> stocks = new ArrayList<Stocks>();
		try {
			
			stocks = this.stockWatchlistService.getStockWatchlistByUser(userService.getUserById(id));
			return stocks;
		} catch (WatchlistServiceException e) {
			stocks=null;
			return stocks;
		}
	}
	
	@RequestMapping(value="{userid}/{sid}", method = RequestMethod. GET)
	public String AddToStockWatchlist( @PathVariable("userid") int userid, @PathVariable("sid") int sid){
		try {
			Stocks stock = stocksService.getStocks(sid);
			User user = userService.getUserById(userid);
			this.stockWatchlistService.addToStockWatchlist(user, stock);
			return "product added Successfully";
		} catch (ProductsServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		} catch (WatchlistServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		}
		
	}
	@RequestMapping(value="delete/{userid}/{sid}", method = RequestMethod.DELETE)
	public String deleteFromWatchlist(@PathVariable("userid") int userid , @PathVariable("sid") int sid) 
	{
		try {
			Stocks stock = stocksService.getStocks(sid);
			User user = userService.getUserById(userid);
			this.stockWatchlistService.deleteFromStockWatchlist(user, stock);
			return "product deleted successfully";
		} catch (ProductsServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		} catch (WatchlistServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		}
		
	}
}
