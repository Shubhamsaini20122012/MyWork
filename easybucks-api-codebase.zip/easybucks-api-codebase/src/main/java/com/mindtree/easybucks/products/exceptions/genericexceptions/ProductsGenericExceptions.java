package com.mindtree.easybucks.products.exceptions.genericexceptions;

import com.mindtree.easybucks.products.exceptions.ProductsExceptions;

public class ProductsGenericExceptions extends ProductsExceptions{

	private static final long serialVersionUID = 1L;

	public ProductsGenericExceptions() {
		super();
	}

	public ProductsGenericExceptions(String arg0, Throwable arg1) {
		super(arg0,arg1);
	}
}
