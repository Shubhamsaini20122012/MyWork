package com.mindtree.easybucks.trackexpense.exception.genericexception;

import com.mindtree.easybucks.trackexpense.exception.ExpenseException;

public class GenericException extends ExpenseException{

	private static final long serialVersionUID = 1L;

	public GenericException() {
		super();
	}

	public GenericException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
