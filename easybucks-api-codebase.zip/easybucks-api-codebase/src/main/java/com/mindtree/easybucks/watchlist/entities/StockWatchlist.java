package com.mindtree.easybucks.watchlist.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.signup.entity.User;
@Entity
@Table(name="stockwatchlist")
public class StockWatchlist {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int stockWatchlistId;
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToMany
	private Set<Stocks> stockList = new HashSet<Stocks>(0);
	
	public StockWatchlist() {
		super();
	}
	
	
	public StockWatchlist(int stockWatchlistId, User user, Set<Stocks> stockList) {
		super();
		this.stockWatchlistId = stockWatchlistId;
		this.user = user;
		this.stockList = stockList;
	}


	public int getStockWatchlistId() {
		return stockWatchlistId;
	}
	public void setStockWatchlistId(int stockWatchlistId) {
		this.stockWatchlistId = stockWatchlistId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<Stocks> getStockList() {
		return stockList;
	}
	public void setStockList(Set<Stocks> stockList) {
		this.stockList = stockList;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + stockWatchlistId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StockWatchlist other = (StockWatchlist) obj;
		if (stockWatchlistId != other.stockWatchlistId)
			return false;
		return true;
	}
	
	

}
