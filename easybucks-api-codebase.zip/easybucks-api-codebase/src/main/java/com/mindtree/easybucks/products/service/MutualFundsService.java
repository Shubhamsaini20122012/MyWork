package com.mindtree.easybucks.products.service;

import java.util.List;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;

public interface MutualFundsService {

	String addMutualFunds(MutualFunds mutualFunds) throws ProductsServiceException ;
	List<MutualFunds> getAllFunds() throws ProductsServiceException ;
	MutualFunds getMutualFunds(int id) throws ProductsServiceException ;
	String deleteMutualFunds(int id) throws ProductsServiceException ;
}
