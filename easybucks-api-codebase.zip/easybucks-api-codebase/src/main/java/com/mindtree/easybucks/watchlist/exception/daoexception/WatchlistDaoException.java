package com.mindtree.easybucks.watchlist.exception.daoexception;

import com.mindtree.easybucks.watchlist.exception.WatchlistException;

public class WatchlistDaoException extends WatchlistException {

	private static final long serialVersionUID = 1L;

	public WatchlistDaoException() {
		super();
	}

	public WatchlistDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	

}
