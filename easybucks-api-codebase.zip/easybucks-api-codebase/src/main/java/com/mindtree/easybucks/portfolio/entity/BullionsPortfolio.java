package com.mindtree.easybucks.portfolio.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.easybucks.products.entities.Bullions;

@Entity
@Table(name = "bullions_portfolio")
public class BullionsPortfolio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "bullions_port_id")
	private int bullionsPortId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "bullions_prod_id")
	private Bullions bullionProd;
	
	@Column
	private int quantity;

	public int getBullionsPortId() {
		return bullionsPortId;
	}

	public void setBullionsPortId(int bullionsPortId) {
		this.bullionsPortId = bullionsPortId;
	}

	public Bullions getBullionProd() {
		return bullionProd;
	}

	public void setBullionProd(Bullions bullionProd) {
		this.bullionProd = bullionProd;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "BullionsPortfolio [bullionsPortId=" + bullionsPortId + ", bullionProd=" + bullionProd + ", quantity="
				+ quantity + "]";
	}
	
}
