package com.mindtree.easybucks.watchlist.dao.stockmarket;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

public interface StockWatchlistDao {

	public boolean addToStockWatchlist(User user,Stocks stock) throws WatchlistDaoException;
	public boolean deleteFromStockWatchlist(User user, Stocks stock ) throws WatchlistDaoException;
	public List<Stocks> getStockWatchlistByUser(User user) throws WatchlistDaoException;
	public Set<Stocks> getStockWatchlistByUser1(User user) throws WatchlistDaoException;

}
