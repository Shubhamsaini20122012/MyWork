package com.mindtree.easybucks.portfolio.dao;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;

public interface PortfolioDao {
	
	public boolean addToPortfolio(Portfolio portfolio) throws PortfolioDaoException;
	
	public boolean deletePortfolio(Portfolio portfolio) throws PortfolioDaoException;
	
	public boolean updatePortfolio(Portfolio portfolio) throws PortfolioDaoException;
	
	public List<Portfolio> getAllPortfolio() throws PortfolioDaoException;
	
	public Portfolio getPortfolioByUserId(int userId) throws PortfolioDaoException;

}
