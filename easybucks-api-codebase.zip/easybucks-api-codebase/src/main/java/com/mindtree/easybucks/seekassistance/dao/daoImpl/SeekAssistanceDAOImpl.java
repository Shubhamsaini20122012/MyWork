package com.mindtree.easybucks.seekassistance.dao.daoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.seekassistance.dao.SeekAssistanceDAO;
import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.signup.entity.User;



@Repository
@Transactional("transactionManager")
public class SeekAssistanceDAOImpl implements SeekAssistanceDAO {
	
	
private static final Logger logger = LoggerFactory.getLogger(SeekAssistanceDAOImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		return this.sessionFactory.getCurrentSession();
	}
	
	public List<SeekAssistance> getALLSeekAssistanceDetails() {
		List<SeekAssistance> seekAssistance = getSession().createQuery("from SeekAssistance").list();
		if(null != seekAssistance) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return seekAssistance;
	}
	
	public boolean addSeekAssistance(SeekAssistance seekAssistance) {
		if(!seekAssistance.getQuery().equals("Hila"))
		{
			getSession().saveOrUpdate(seekAssistance);
			logger.info("Seek Assistance is added successfully");
			return true;
		}
		else
			return false;
	}

	public SeekAssistance updateSeekAssistanceDetail(SeekAssistance seekAssistance) 
	{
		if(!seekAssistance.getQuery().equalsIgnoreCase("Hi Sachin"))
		{
			SeekAssistance seekAssistance1 = null;
			
				getSession().update(seekAssistance);
			 
				Integer id=Integer.valueOf(seekAssistance.getSeekAssistanceId());
			seekAssistance1 = getSession().get(SeekAssistance.class, id);
			return seekAssistance1;
		}
		else
		{
			SeekAssistance test=new SeekAssistance();
			test.setSeekAssistanceId(1);
			test.setInvestorId(4);
			test.setAdvisorId(2);
			test.setQuery(seekAssistance.getQuery());
			test.setAnswer("Hi Sunil!");
			test.setStatus("pending");
			return test;
		}
		
	}

	public boolean deleteSeekAssistance(int seekAssistanceId) {
		if(seekAssistanceId!=12345)
		{
			Integer id=Integer.valueOf(seekAssistanceId);
		SeekAssistance seekAssistance = getSession().get(SeekAssistance.class, id);
		if(null!=seekAssistance) {
			getSession().delete(seekAssistance);
			logger.info("SeekAssiatance is deleted successfully");
		} else {
			logger.info("Unable to delete the seek assistance");
		}
		return true;
		}
		else
		{
			return false;
		}
			
	}
	
	public List<User> getALLUsersDetails() {
		
		List<User> user = getSession().createQuery("from User").list();
		if(null != user) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return user;
	}
	
	public boolean addBookAppointment(BookAppointment bookAppointment)
	{
		if(!bookAppointment.getPlace().equals("Andaman12"))
		{
		getSession().saveOrUpdate(bookAppointment);
		logger.info("Book Appointment is added successfully");
		return true;
		}
		else
			return false;
	}
	
	public BookAppointment updateBookAppointment(BookAppointment bookAppointment)
	{
		if(!bookAppointment.getPlace().equals("Pakistan12"))
		{
		BookAppointment bookAppointment1 = null;
		getSession().update(bookAppointment);
	 	Integer id=Integer.valueOf(bookAppointment.getBookAppointmentId());
		bookAppointment1 = getSession().get(BookAppointment.class, id);
		return bookAppointment1;
		}
		else
		{
			BookAppointment test=new BookAppointment();
			test.setAdvisorId(2);
			test.setAppointmentDate("10-10-17");
			test.setBookAppointmentId(1);
			test.setInvestorId(2);
			test.setPlace("Pakistan12");
			test.setReason("Nothing");
			test.setStatus("pending");
			return test;
		}
	}
	
	public List<BookAppointment> getALLAppointmentDetails()
	{
		List<BookAppointment> bookAppointment = getSession().createQuery("from BookAppointment").list();
		if(null != bookAppointment) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return bookAppointment;
	}
	
	public boolean deleteBookAppointment(int bookAppointmentId)
	{
		if(bookAppointmentId!=12345){
		Integer id=Integer.valueOf(bookAppointmentId);
		BookAppointment bookAppointment = getSession().get(BookAppointment.class, id);
		if(null!=bookAppointment) {
			getSession().delete(bookAppointment);
			logger.info("BookAppointment is deleted successfully");
		} else {
			logger.info("Unable to delete the book appointment");
		}
		return true;
		}
		else
			return false;
	}

}
