package com.mindtree.easybucks.seekassistance.dto;

public class SeekAssistanceUpdateDTO 
{
	private int seekAssistanceId;
	private int investor;
	private int advisor;
	private String query;
	private String answer;
	private String status;
	public SeekAssistanceUpdateDTO() {
		super();
		
	}
	@Override
	public String toString() {
		return "SeekAssistance [seekAssistanceId=" + seekAssistanceId + ", investor=" + investor + ", advisor="
				+ advisor + ", query=" + query + ", answer=" + answer + ", status=" + status + "]";
	}
	public int getSeekAssistanceId() {
		return seekAssistanceId;
	}
	public void setSeekAssistanceId(int seekAssistanceId) {
		this.seekAssistanceId = seekAssistanceId;
	}
	public int getInvestor() {
		return investor;
	}
	public void setInvestor(int investor) {
		this.investor = investor;
	}
	public int getAdvisor() {
		return advisor;
	}
	public void setAdvisor(int advisor) {
		this.advisor = advisor;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
