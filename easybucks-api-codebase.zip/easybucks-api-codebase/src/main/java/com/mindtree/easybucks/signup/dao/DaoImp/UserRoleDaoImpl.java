package com.mindtree.easybucks.signup.dao.DaoImp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.signup.dao.UserRoleDao;
import com.mindtree.easybucks.signup.entity.UserRole;

@Repository
@Transactional("transactionManager")
public class UserRoleDaoImpl implements UserRoleDao {

	@Autowired
	private SessionFactory sessionFactory;
	

	public boolean addUserRole(UserRole userRole) {
		sessionFactory.getCurrentSession().saveOrUpdate(userRole);
		return true;
	}

	public List<UserRole> getUserRole() {
		List<UserRole> list = new ArrayList<UserRole>();
		list = sessionFactory.getCurrentSession().createQuery("from UserRole").list();
		return list;
	}

	public UserRole getUserRoleById(int id) {
		UserRole userRole = new UserRole();
		userRole = sessionFactory.getCurrentSession().get(UserRole.class, new Integer(id));
		return userRole;
	}
}
