package com.mindtree.easybucks.watchlist.dao.mutualfund;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

public interface MutualFundWatchlistDao {
	
	public boolean addToMutualFundWatchlist(User user,MutualFunds mutualFund) throws WatchlistDaoException;
	public boolean deleteFromMutualFundWatchlist(User user,MutualFunds mutualFund) throws WatchlistDaoException;
	public List<MutualFunds> getMutualFundWatchlistByUser(User user)throws WatchlistDaoException ;
	public Set<MutualFunds> getMutualFundWatchlistByUser1(User user) throws WatchlistDaoException;

}
