package com.mindtree.easybucks.products.service.serviceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.dao.MutualFundsDao;
import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.MutualFundsService;

@Service
public class MutualFundsServiceImpl implements MutualFundsService {

	@Autowired
	private MutualFundsDao mutualFundsDao;

	public void setMutualFundsDao(MutualFundsDao mutualFundsDao) {
		this.mutualFundsDao = mutualFundsDao;
	}

	@Transactional
	public String addMutualFunds(MutualFunds mutualFunds) throws ProductsServiceException {
		try {
			return this.mutualFundsDao.addMutualFunds(mutualFunds);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to add data from service", e);
		}
	}

	public List<MutualFunds> getAllFunds() throws ProductsServiceException {
		try {
			return this.mutualFundsDao.getAllFunds();
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch list from service", e);
		}
	}
	
	public MutualFunds getMutualFunds(int id) throws ProductsServiceException {
		try {
			return this.mutualFundsDao.getMutualFunds(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch data from service", e);
		}
	}
	
	public String deleteMutualFunds(int id) throws ProductsServiceException {
		try {
			return this.mutualFundsDao.deleteMutualFunds(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to delete data from service", e);
		}
	}

}
