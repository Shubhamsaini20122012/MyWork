package com.mindtree.easybucks.login.dto;

import com.mindtree.easybucks.signup.entity.User;

public class LogInResponse {
	
	private String response;
	
	private  User user;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "LogInResponse [response=" + response + ", user=" + user + "]";
	}
	
	
}
