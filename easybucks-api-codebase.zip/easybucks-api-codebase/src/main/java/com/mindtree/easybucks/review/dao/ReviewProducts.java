package com.mindtree.easybucks.review.dao;

import java.util.List;

import com.mindtree.easybucks.review.dto.Users;
import com.mindtree.easybucks.review.entity.WriteReviewBanking;
import com.mindtree.easybucks.review.entity.WriteReviewBullion;
import com.mindtree.easybucks.review.entity.WriteReviewMf;
import com.mindtree.easybucks.review.entity.WriteReviewStocks;


public interface ReviewProducts {
	
public void addCommentsToWriteReviewBullion(Users write);
public void addCommentsToWriteReviewMf(Users write);
public void addCommentsToWriteReviewStocks(Users write);
public void addCommentsToWriteReviewBanking(Users write);
public List<WriteReviewBanking> getBankingReview();
public List<WriteReviewBullion> getBullionReview();
public List<WriteReviewStocks> getStocksReview();
public List<WriteReviewMf> getMfReview();


}
