package com.mindtree.easybucks.watchlist.services.bullionservice;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

public interface BullionWatchlistService {
	
	public boolean addToBullionWatchlist(User user,Bullions bullion) throws WatchlistServiceException;
	public boolean deleteFromBullionWatchlist(User user,Bullions bullion) throws WatchlistServiceException;
	public List<Bullions> getBullionWatchlistByUser(User user) throws WatchlistServiceException;
	public Set<Bullions> getBullionWatchlistByUser1(User user) throws WatchlistServiceException;

}
