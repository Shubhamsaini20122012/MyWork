package com.mindtree.easybucks.watchlist.services.mutualfundservice;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.dao.mutualfund.MutualFundWatchlistDao;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

@Service
public class MutualFundWatchlistServiceImp implements MutualFundWatchlistService{

	@Autowired
	private MutualFundWatchlistDao mutualFundWatchlistDao;

	public boolean addToMutualFundWatchlist(User user, MutualFunds mutualFunds) throws WatchlistServiceException {
		try {
			return this.mutualFundWatchlistDao.addToMutualFundWatchlist(user, mutualFunds);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to add data from service",e) ;
		}
	}

	public boolean deleteFromMutualFundWatchlist(User user, MutualFunds mutualFunds) throws WatchlistServiceException {
		try {
			return this.mutualFundWatchlistDao.deleteFromMutualFundWatchlist(user, mutualFunds);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to delete data from service",e) ;
		}
		
	}
	
	public List<MutualFunds> getMutualFundWatchlistByUser(User user) throws WatchlistServiceException {
		try {
			return this.mutualFundWatchlistDao.getMutualFundWatchlistByUser(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

	public Set<MutualFunds> getMutualFundWatchlistByUser1(User user) throws WatchlistServiceException {
		try {
			return this.mutualFundWatchlistDao.getMutualFundWatchlistByUser1(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

}
