package com.mindtree.easybucks.watchlist.exception;

public class WatchlistException extends Exception {

	private static final long serialVersionUID = 1L;

	public WatchlistException() {
		super();
	}

	public WatchlistException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
