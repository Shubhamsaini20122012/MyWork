package com.mindtree.easybucks.watchlist.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.signup.entity.User;
@Entity
@Table(name="bankingwatchlist")
public class BankingWatchlist {

	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int bankingWatchlistId;
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToMany
	private Set<Banking> bankingList = new HashSet<Banking>(0);
	public BankingWatchlist() {
		super();
	}
	public BankingWatchlist(int bankingWatchlistId, User user, Set<Banking> bankingList) {
		super();
		this.bankingWatchlistId = bankingWatchlistId;
		this.user = user;
		this.bankingList = bankingList;
	}
	public int getBankingWatchlistId() {
		return bankingWatchlistId;
	}
	public void setBankingWatchlistId(int bankingWatchlistId) {
		this.bankingWatchlistId = bankingWatchlistId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<Banking> getBankingList() {
		return bankingList;
	}
	public void setBankingList(Set<Banking> bankingList) {
		this.bankingList = bankingList;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bankingWatchlistId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankingWatchlist other = (BankingWatchlist) obj;
		if (bankingWatchlistId != other.bankingWatchlistId)
			return false;
		return true;
	}
	
	
	
}
