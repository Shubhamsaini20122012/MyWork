package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.StocksPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.StocksPortfolioService;

public class StocksPortfolioServiceImpl implements StocksPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;

	public boolean addStocksPortfolioByUserId(StocksPortfolio stocksPortfolio, int userId)
			throws StocksPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error In gettin portfolio by userid in stocks Service", e.getCause()); 
		}
		
		List<StocksPortfolio> stocksPortList = portfolio.getStocksPort();
		stocksPortList.remove(stocksPortfolio);
		portfolio.setStocksPort(stocksPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in updating portfolio in stocks Service", e.getCause());
		}
	}

	public boolean deleteStocksPortfolioByUserId(StocksPortfolio stocksPortfolio, int userId)
			throws StocksPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in getting portfolio in stocks Service", e.getCause());
		}
		
		List<StocksPortfolio> stockPortList = portfolio.getStocksPort();
		stockPortList.remove(stocksPortfolio);
		portfolio.setStocksPort(stockPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in updating portfolio in Stocks Service", e.getCause());
		}
	}

	public List<StocksPortfolio> getStocksPortfolioByuserId(int userId) throws StocksPortfolioServiceException {
		try{
			Portfolio portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getStocksPort();
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in getting portfolio in Stocks Service", e.getCause());
		}
	}
	
	

}





