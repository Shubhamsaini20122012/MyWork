package com.mindtree.easybucks.portfolio.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.easybucks.products.entities.Stocks;

@Entity
@Table(name = "stocks_portfolio")
public class StocksPortfolio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "stocks_port_id")
	private int stocksPortId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "stocks_prod_id")
	private Stocks stocksProd;
	
	@Column(name = "purchase_price")
	private long purchasePrice;
	
	@Column(name = "no_of_shares")
	private int noOfShares;

	public int getStocksPortId() {
		return stocksPortId;
	}

	public void setStocksPortId(int stocksPortId) {
		this.stocksPortId = stocksPortId;
	}

	public Stocks getStocksProd() {
		return stocksProd;
	}

	public void setStocksProd(Stocks stocksProd) {
		this.stocksProd = stocksProd;
	}

	public long getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(long purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public int getNoOfShares() {
		return noOfShares;
	}

	public void setNoOfShares(int noOfShares) {
		this.noOfShares = noOfShares;
	}

	@Override
	public String toString() {
		return "StocksPortfolio [stocksPortId=" + stocksPortId + ", stocksProd=" + stocksProd + ", purchasePrice="
				+ purchasePrice + ", noOfShares=" + noOfShares + "]";
	}
	
	
}






