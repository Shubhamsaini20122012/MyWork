package com.mindtree.easybucks.signup.service.EasyService;

import java.util.List;



import com.mindtree.easybucks.signup.dto.AdvisorRequestsDto;
import com.mindtree.easybucks.signup.dto.AdvisorRequestsUpdateDto;
import com.mindtree.easybucks.signup.dto.SignUpDto;
import com.mindtree.easybucks.signup.entity.AdvisorRequests;
import com.mindtree.easybucks.signup.entity.User;

public interface UserService {
	public String adduser(SignUpDto signUpDto);
	public List<User> getUsers();
	public List<String> getEmail();
	public User getUserById(int userId);
	public boolean deleteUser(int userId);
	
	public boolean addAdvisorRequest(AdvisorRequestsDto advisorRequestsDto);
	public AdvisorRequests updateAdvisorRequest(AdvisorRequestsUpdateDto advisorRequestsUpdateDto);
	public boolean deleteAdvisorRequest(int advisorRequestId);
	public List<AdvisorRequests>  getALLAdvisorRequests();
	
}
