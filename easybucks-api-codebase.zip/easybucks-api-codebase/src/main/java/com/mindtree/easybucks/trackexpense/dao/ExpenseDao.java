package com.mindtree.easybucks.trackexpense.dao;

import java.util.List;

import com.mindtree.easybucks.trackexpense.entities.Expense;
import com.mindtree.easybucks.trackexpense.exception.daoexception.ExpenseDaoException;

public interface ExpenseDao {

	public boolean addExpense(Expense expense) throws ExpenseDaoException ;
	public boolean deleteExpense(Expense expense) throws ExpenseDaoException;
	public Expense updateExpense(Expense expense) throws ExpenseDaoException ;
	public Expense getExpenseById(int id) throws ExpenseDaoException;
	public List<Expense> getAllExpenses(int userId) throws ExpenseDaoException;
}

