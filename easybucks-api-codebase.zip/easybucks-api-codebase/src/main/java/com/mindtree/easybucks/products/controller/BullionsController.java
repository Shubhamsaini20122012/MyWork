package com.mindtree.easybucks.products.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BullionsService;

@CrossOrigin
@RestController
@RequestMapping(value="/products/bullions")
public class BullionsController {
	
	@Autowired
	private BullionsService bullionsService ;

	public void setBullionsService(BullionsService bullionsService) {
		this.bullionsService = bullionsService;
	}
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	public String addBullions(@RequestBody Bullions bullions)
	{
		try {
			return this.bullionsService.addBullions(bullions);
		} catch (ProductsServiceException e1) {
			return (e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/all", method = RequestMethod.GET)
	public List<Bullions> getAllBullions(){
		List<Bullions> bullionsList=new ArrayList();
		try {
			bullionsList=this.bullionsService.getAllBullions();
		} catch (ProductsServiceException e) {
			bullionsList= null ;
		}
		return bullionsList;
	}
	
	@RequestMapping(value="/delete/{Id}", method = RequestMethod.DELETE)
	public String deleteBullions(@PathVariable("Id")int id)
	{
		try {
			return this.bullionsService.deleteBullions(id) ;
		} catch (ProductsServiceException e1) {
			return(e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/{Id}", method = RequestMethod.GET)
	public Bullions getBullions(@PathVariable("Id")int id){
		Bullions bullions = new Bullions() ;
		try {
			bullions = this.bullionsService.getBullions(id) ;
		} catch (ProductsServiceException e) {
			bullions = null ;
		}
		return bullions ;
	}
}
