package com.mindtree.easybucks.portfolio.exception.serviceexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class BullionsPortfolioServiceException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public BullionsPortfolioServiceException() {
		super();
	}

	public BullionsPortfolioServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
