package com.mindtree.easybucks.signup.service.EasyService;

import java.util.List;

import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.entity.UserRole;

public interface UserRoleService {
	public boolean adduserRole(UserRole user);
	public List<UserRole> getUserRole();
	public UserRole getUserRoleById(int id ); 
}
