package com.mindtree.easybucks.profile.services.servicesImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.easybucks.profile.dao.ProfileDao;
import com.mindtree.easybucks.profile.dto.ProfileDto;
import com.mindtree.easybucks.profile.services.ProfileService;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.entity.UserRole;

@Service
public class ProfileServiceImpl implements ProfileService {

	@Autowired
	private ProfileDao profileDao;

	public void setProfileDao(ProfileDao profileDao) {
		this.profileDao = profileDao;
	}

	public User getProfile(int userId) {
	
		return profileDao.getProfile(userId);
	}

	public User updateProfile(ProfileDto profileDto) {
		User user=new User();
		UserRole role=new UserRole();
		
		role.setRoleId(profileDto.getRoleId());
		
		user.setUserId(profileDto.getUserId());
		user.setUserRole(role);
		user.setUserOccupation(profileDto.getUserOccupation());
		user.setUserCity(profileDto.getUserCity());
		user.setUserIncome((double)profileDto.getUserIncome());
		user.setUserPhone((long)profileDto.getUserPhone());

		
		user.setUserEmail(profileDto.getUserEmail());
		user.setUserName(profileDto.getUserName());
		user.setUserPassword(profileDto.getUserPassword());
		user.setUserDob(profileDto.getUserDOB());
		
		return this.profileDao.updateProfile(user);
	}

}
