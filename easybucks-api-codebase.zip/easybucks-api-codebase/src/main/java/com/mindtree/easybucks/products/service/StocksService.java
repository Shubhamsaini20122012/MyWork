package com.mindtree.easybucks.products.service;

import java.util.List;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;

public interface StocksService {
	
	String addStocks(Stocks stocks) throws ProductsServiceException ;
	List<Stocks> getAllStocks() throws ProductsServiceException ;
	Stocks getStocks(int id) throws ProductsServiceException ;
	String deleteStocks(int id) throws ProductsServiceException ;
}
