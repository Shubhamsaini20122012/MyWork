package com.mindtree.easybucks.signup.dao;

import java.util.List;

import com.mindtree.easybucks.signup.entity.UserRole;

public interface UserRoleDao {
	public boolean addUserRole(UserRole userRole);
	public List<UserRole> getUserRole();
	public UserRole getUserRoleById(int id ); 
	

}
