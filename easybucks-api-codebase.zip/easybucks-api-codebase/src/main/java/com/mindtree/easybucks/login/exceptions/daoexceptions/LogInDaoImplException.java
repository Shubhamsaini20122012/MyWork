package com.mindtree.easybucks.login.exceptions.daoexceptions;

public class LogInDaoImplException extends LogInDaoException {

	private static final long serialVersionUID = 1L;

	public LogInDaoImplException() {
		super();
	}

	public LogInDaoImplException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}


}
