package com.mindtree.easybucks.products.exceptions.daoexceptions;

import com.mindtree.easybucks.products.exceptions.ProductsExceptions;

public class ProductsDaoException extends ProductsExceptions{

	private static final long serialVersionUID = 1L;

	public ProductsDaoException() {
		super();
	}

	public ProductsDaoException(String arg0, Throwable arg1) {
		super(arg0,arg1);
	}
}
