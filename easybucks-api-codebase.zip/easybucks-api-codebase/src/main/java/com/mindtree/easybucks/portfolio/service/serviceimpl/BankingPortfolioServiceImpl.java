package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BankingPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.BankingPortfolioService;

@Service
public class BankingPortfolioServiceImpl implements BankingPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;

	public boolean addBankingPortfolioByUserId(BankingPortfolio bankingPortfolio, int userId)
			throws BankingPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in getting portfolio by id in Banking portfolio service", e.getCause());
		}
		
		List<BankingPortfolio> bankingPortList = portfolio.getBankingPort();
		bankingPortList.add(bankingPortfolio);
		portfolio.setBankingPort(bankingPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in updating banking portfolio in banking sevice", e.getCause());
		}
	}

	public boolean deleteBankingPortfolioByUserId(BankingPortfolio bankingPortfolio, int userId)
			throws BankingPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in getting portfolio by user Id in Banking service", e.getCause());
		}
		
		List<BankingPortfolio> bankingPortList = portfolio.getBankingPort();
		bankingPortList.remove(bankingPortfolio);
		portfolio.setBankingPort(bankingPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in updating portfolio by user id in banking service", e.getCause());
		}
	}

	public List<BankingPortfolio> getPortfolioByUserId(int userId) throws BankingPortfolioServiceException {
		Portfolio portfolio;
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getBankingPort();
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in getting portfolio by userId in banking Service", e.getCause());
		}
	}

}





