package com.mindtree.easybucks.review.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.review.dao.ReviewProducts;
import com.mindtree.easybucks.review.dto.Users;
import com.mindtree.easybucks.review.entity.WriteReviewBanking;
import com.mindtree.easybucks.review.entity.WriteReviewBullion;
import com.mindtree.easybucks.review.entity.WriteReviewMf;
import com.mindtree.easybucks.review.entity.WriteReviewStocks;

@Service
public class ReviewProductsServicesImpl implements ReviewProductsService {

	@Autowired
	private ReviewProducts reviewProducts;
	public void setReviewProducts(ReviewProducts reviewProducts){
		this.reviewProducts=reviewProducts;
	}
	
	public void addCommentsToWriteReviewBullion(Users write) {
		
		this.reviewProducts.addCommentsToWriteReviewBullion(write);
	}

	public void addCommentsToWriteReviewMf(Users write) {
		reviewProducts.addCommentsToWriteReviewMf(write);
		
	}

	public void addCommentsToWriteReviewStocks(Users write) {
		
		reviewProducts.addCommentsToWriteReviewStocks(write);
	}

	public void addCommentsToWriteReviewBanking(Users write) {
		
		reviewProducts.addCommentsToWriteReviewBanking(write);
	}

	public List<WriteReviewBanking> getBankingReview() {
		 return reviewProducts.getBankingReview();
	}
 
	public List<WriteReviewBullion> getBullionReview() {
		return reviewProducts.getBullionReview();
	}

	public List<WriteReviewStocks> getStocksReview() {
		return reviewProducts.getStocksReview();
	}

	public List<WriteReviewMf> getMfReview() {
		return reviewProducts.getMfReview();
	}

}
