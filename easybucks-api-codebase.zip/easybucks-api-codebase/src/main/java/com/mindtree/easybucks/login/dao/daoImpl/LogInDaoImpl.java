package com.mindtree.easybucks.login.dao.daoImpl;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.login.dao.LogInDao;
import com.mindtree.easybucks.login.exceptions.daoexceptions.LogInDaoImplException;
import com.mindtree.easybucks.signup.entity.User;

@Repository
@Transactional("transactionManager")
public class LogInDaoImpl implements LogInDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public Session getSession(){
			return this.sessionFactory.getCurrentSession();
	}

	public User getUserByEmail(String userEmail) throws LogInDaoImplException {
		
		try{
				Query query = getSession().createQuery("FROM User WHERE userEmail = :para");
				query.setParameter("para", userEmail);
				@SuppressWarnings("unchecked")
				List<User> user =(List<User>)query.list();
				return user.get(0);
		}
		catch(HibernateException hbException){
			throw new LogInDaoImplException("Error in fetching User details ", hbException);
		}
		catch(NoResultException resultException){
			throw new LogInDaoImplException("Error in getting result in Dao", resultException.getCause());
		}
		catch(IndexOutOfBoundsException outOfBoundException){
			throw new LogInDaoImplException("User Not Registered", outOfBoundException);
		}

	}

	public boolean updatePassword(User user) throws LogInDaoImplException {
		try{
			getSession().update(user);
			return true;
		}
		catch(HibernateException hibernateException){
			throw new LogInDaoImplException("cannot update password error in DAO", hibernateException.getCause());
		}
	}
}
