package com.mindtree.easybucks.watchlist.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BullionsService;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.bullionservice.BullionWatchlistService;

@CrossOrigin
@RestController
@RequestMapping(value="/watchlist/bullions")
public class BullionWatchlistController {

	@Autowired
	private UserService userService;
	@Autowired
	private BullionWatchlistService bullionWatchlistService;
	@Autowired
	private BullionsService bullionsService;
	
	@RequestMapping(value="/all/{id}", method = RequestMethod.GET)
	public List<Bullions>  getAllBullions( @PathVariable("id") Integer id) {
		List<Bullions> bullions = new ArrayList<Bullions>();
		try {
			bullions = this.bullionWatchlistService.getBullionWatchlistByUser(userService.getUserById(id));
			return bullions;
		} catch (WatchlistServiceException e) {
			bullions=null;
			return bullions;
		}
	}
	
	@RequestMapping(value="{userid}/{bid}", method = RequestMethod. GET)
	public String AddToBullionWatchlist( @PathVariable("userid") int userid, @PathVariable("bid") int bid) {
			 try {
				Bullions bullion = bullionsService.getBullions(bid);
				 User user = userService.getUserById(userid);
				 this.bullionWatchlistService.addToBullionWatchlist(user, bullion);
				 return "product added successfully";
			} catch (ProductsServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			} catch (WatchlistServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			}
		
	}
	@RequestMapping(value="delete/{userid}/{bid}", method = RequestMethod.DELETE)
	public String deleteFromWatchlist(@PathVariable("userid") int userid , @PathVariable("bid") int bid)
	{
		try {
			Bullions bullion = bullionsService.getBullions(bid);
			 User user = userService.getUserById(userid);
			 this.bullionWatchlistService.deleteFromBullionWatchlist(user, bullion);
			return "product deleted successfully";
		} catch (ProductsServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		} catch (WatchlistServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		}
		
	}
}
