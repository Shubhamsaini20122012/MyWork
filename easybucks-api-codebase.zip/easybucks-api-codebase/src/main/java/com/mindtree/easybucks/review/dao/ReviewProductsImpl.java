package com.mindtree.easybucks.review.dao;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.review.dto.Users;
import com.mindtree.easybucks.review.entity.WriteReviewBanking;
import com.mindtree.easybucks.review.entity.WriteReviewBullion;
import com.mindtree.easybucks.review.entity.WriteReviewMf;
import com.mindtree.easybucks.review.entity.WriteReviewStocks;


@Repository
@Transactional("transactionManager")
public class ReviewProductsImpl implements ReviewProducts {
	
	private static final Logger logger = LoggerFactory.getLogger(ReviewProductsImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
			return this.sessionFactory.getCurrentSession();
	}
	
	public void closeSession() {
		this.sessionFactory.close();
	}

	public void addCommentsToWriteReviewBullion(Users write) {
      
		String commnet=write.getComment();
		String rating=write.getRating();
		WriteReviewBullion writeReviewBullion = new WriteReviewBullion();
		writeReviewBullion.setReview(commnet);
		writeReviewBullion.setStars(rating);
		getSession().save(writeReviewBullion);
	}
	
	public void addCommentsToWriteReviewMf(Users write) {
		
		String commnet=write.getComment();
		String rating=write.getRating();
		WriteReviewMf m=new WriteReviewMf();
		m.setReview(commnet);
		m.setStars(rating);
		getSession().save(m);
	}

	public void addCommentsToWriteReviewStocks(Users write) {
		
		String comment = write.getComment();
		String rating = write.getRating();
		List<WriteReviewStocks> list=new ArrayList<WriteReviewStocks>();
		WriteReviewStocks writeReviewStock = new WriteReviewStocks();
		writeReviewStock.setReview(comment);
		writeReviewStock.setStars(rating);
		list.add(writeReviewStock);
		getSession().save(writeReviewStock);
	}

	public void addCommentsToWriteReviewBanking(Users write) {
		
		String comment = write.getComment();
		String rating = write.getRating();
		WriteReviewBanking writeReviewBanking = new WriteReviewBanking();
		writeReviewBanking.setReview(comment);
		writeReviewBanking.setStars(rating);
		getSession().save(writeReviewBanking);
	}

	public List<WriteReviewBanking> getBankingReview() {
		List<WriteReviewBanking> writeReviewBanking = getSession().createQuery("from WriteReviewBanking").list();
		/*closeSession();*/
		return writeReviewBanking;

		
	}

	public List<WriteReviewBullion> getBullionReview() {
		List<WriteReviewBullion> writeReviewBullion = getSession().createQuery("from WriteReviewBullion").list();
          return writeReviewBullion; 

	}

	public List<WriteReviewStocks> getStocksReview() {
		List<WriteReviewStocks> writeReviewStocks = getSession().createQuery("from WriteReviewStocks").list();
        return writeReviewStocks; 
	}

	public List<WriteReviewMf> getMfReview() {
		List<WriteReviewMf> writeReviewMf = getSession().createQuery("from WriteReviewMf").list();
        return writeReviewMf; 
	}
}
