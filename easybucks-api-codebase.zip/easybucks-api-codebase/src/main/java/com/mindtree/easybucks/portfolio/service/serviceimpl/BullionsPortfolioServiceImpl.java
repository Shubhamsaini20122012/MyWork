package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BullionsPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BullionsPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.BullionsPortfolioService;

@Service
public class BullionsPortfolioServiceImpl implements BullionsPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;

	public boolean addBullionsPortfolioByUserId(BullionsPortfolio bullionsPortfolio, int userId)
			throws BullionsPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in getting portfolio by user id in bullion service", e.getCause());
		}
		
		List<BullionsPortfolio> bullionsPortList = portfolio.getBullionsPort();
		bullionsPortList.add(bullionsPortfolio);
		portfolio.setBullionsPort(bullionsPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in updating portfolio in bullions Service", e.getCause());
		}
	}

	public boolean deleteBullionsPortfolioByUserId(BullionsPortfolio bullionsPortfolio, int userId)
			throws BullionsPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in getting portfolio by user id in bullion service", e.getCause());
		}
		
		List<BullionsPortfolio> bullionsPortList = portfolio.getBullionsPort();
		bullionsPortList.remove(bullionsPortfolio);
		portfolio.setBullionsPort(bullionsPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in updating portfolio in bullions Service", e.getCause());
		}
	}

	public List<BullionsPortfolio> getBullionsPortfolioByUserId(int userId) throws BullionsPortfolioServiceException {
		Portfolio portfolio;
		
		try{
			System.out.println("in getBulions Service");
			portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getBullionsPort();
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in getting portfolio by user id", e.getCause());
		}
	}
	
	

}
