package com.mindtree.easybucks.watchlist.services.stockmarketservice;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.dao.stockmarket.StockWatchlistDao;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

@Service
public class StockWatchlistServiceImp implements StockWatchlistService {
	
	@Autowired
	private StockWatchlistDao stockWatchlistDao;

	public boolean addToStockWatchlist(User user, Stocks stock) throws WatchlistServiceException {
		try {
			this.stockWatchlistDao.addToStockWatchlist(user, stock);
			return true;
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to add data from service",e) ;
		}
	}


	public boolean deleteFromStockWatchlist(User user, Stocks stock) throws WatchlistServiceException {
		try {
			this.stockWatchlistDao.deleteFromStockWatchlist(user, stock);
			return true;
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to delete data from service",e) ;
		}
	}
	public List<Stocks> getStockWatchlistByUser(User user) throws WatchlistServiceException {
		try {
			return this.stockWatchlistDao.getStockWatchlistByUser(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

	public Set<Stocks> getStockWatchlistByUser1(User user) throws WatchlistServiceException {
		try {
			return this.stockWatchlistDao.getStockWatchlistByUser1(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

}
