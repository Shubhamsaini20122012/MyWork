package com.mindtree.easybucks.profile.dao.daoImpl;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.profile.dao.ProfileDao;
import com.mindtree.easybucks.signup.entity.User;

@Repository
@Transactional("transactionManager")
public class ProfileDaoImp implements ProfileDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public Session getSession() {
		return sessionFactory.getCurrentSession();
	}
	
	public User getProfile(int userId) {
			User user = new User() ;
			user =  getSession().get(User.class, new Integer(userId));
			return user ;
	}

	public User updateProfile(User user) {
		
	if(!user.getUserName().equals("gfgjj"))
		{
		getSession().update(user) ;
		}
		return user ;
	}
}
