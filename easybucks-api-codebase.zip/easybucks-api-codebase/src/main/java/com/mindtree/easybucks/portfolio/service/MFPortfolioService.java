package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.MFPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.MFPortfolioServiceException;

public interface MFPortfolioService {
	
	public boolean addMFPortfolioByUserId(MFPortfolio mfPortfolio, int userId) throws MFPortfolioServiceException;
	
	public boolean deleteMFPortfolioByUserId(MFPortfolio mfPortfolio, int userId) throws MFPortfolioServiceException;
	
	public List<MFPortfolio> getMFPortfolioByUserId(int userId) throws MFPortfolioServiceException;

}
