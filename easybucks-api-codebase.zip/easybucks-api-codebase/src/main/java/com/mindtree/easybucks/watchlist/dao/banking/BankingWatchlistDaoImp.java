package com.mindtree.easybucks.watchlist.dao.banking;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.entities.BankingWatchlist;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

@Repository
@Transactional("transactionManager")
public class BankingWatchlistDaoImp implements BankingWatchlistDao{

	@Autowired
	private SessionFactory sessionFactory;
	

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public boolean addToBankingWatchlist(User user,Banking bank) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(BankingWatchlist.class, new Integer(user.getUserId()))!=null)
		{	
			if(getBankingWatchlistByUser(user).contains(bank)){
			return false;
			}
		}
		else{
			BankingWatchlist bankingWatchList1 = new BankingWatchlist() ;
			bankingWatchList1.setUser(user);
			this.sessionFactory.getCurrentSession().save(bankingWatchList1) ;
		}
			try {
				List<Banking> banks=getBankingWatchlistByUser(user);
				Set<Banking> banks1 = new HashSet<Banking>();
				for(Banking m: banks){
					banks1.add(m);
				}
				banks1.add(bank);
				BankingWatchlist bankingWatchlist = (BankingWatchlist) this.sessionFactory.getCurrentSession().createQuery("from BankingWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
				bankingWatchlist.setBankingList(banks1);
				sessionFactory.getCurrentSession().save(bankingWatchlist);
				return true;
			} catch (Exception e) {
				throw new WatchlistDaoException("No data avaliable",e);
		}
	}

	public boolean deleteFromBankingWatchlist(User user,Banking bank) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(BankingWatchlist.class, new Integer(user.getUserId()))==null){
			return true ;
		}
		try {
			List<Banking> banks=getBankingWatchlistByUser(user);
			Set<Banking> banks1 = new HashSet<Banking>();
			for(Banking m: banks){
				banks1.add(m);
			}
			banks1.remove(bank);
			BankingWatchlist bankingWatchlist = (BankingWatchlist) this.sessionFactory.getCurrentSession().createQuery("from BankingWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			bankingWatchlist.setBankingList(banks1);
			sessionFactory.getCurrentSession().save(bankingWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable",e);
			
		}
		
	}
	
	public List<Banking> getBankingWatchlistByUser(User user) throws WatchlistDaoException {
		try {
			BankingWatchlist bankingWatchlist = (BankingWatchlist) this.sessionFactory.getCurrentSession().createQuery("from BankingWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			Set<Banking> banks=bankingWatchlist.getBankingList();
			List<Banking> banks1 = new ArrayList<Banking>();
			for(Banking b : banks)
			{
				banks1.add(b);
			}
			return banks1;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable",e);
		}
	}

	public Set<Banking> getBankingWatchlistByUser1(User user) throws WatchlistDaoException {
		try {
			BankingWatchlist bankingWatchlist = (BankingWatchlist) this.sessionFactory.getCurrentSession().createQuery("from Bankingwatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			return bankingWatchlist.getBankingList();
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable",e);
		}
	}

}
