package com.mindtree.easybucks.login.exceptions.serviceexceptions;

import com.mindtree.easybucks.login.exceptions.LoginException;

public class LogInServiceException extends LoginException {

	private static final long serialVersionUID = 1L;

	public LogInServiceException() {
		super();
	}

	public LogInServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}


}
