package com.mindtree.easybucks.login.exceptions.serviceexceptions;

public class LogInServiceImplException extends LogInServiceException {

	private static final long serialVersionUID = 1L;

	public LogInServiceImplException() {
		super();
	}

	public LogInServiceImplException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
