package com.mindtree.easybucks.trackexpense.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.trackexpense.entities.Expense;
import com.mindtree.easybucks.trackexpense.exception.daoexception.ExpenseDaoException;

@Repository
@Transactional("transactionManager")
public class ExpenseDaoImpl implements ExpenseDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private UserService userService;
	

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean addExpense(Expense expense) throws ExpenseDaoException {
		 try {
			 System.out.println("In add");
			this.sessionFactory.getCurrentSession().save(expense);
			return true;
		} catch (HibernateException e) {
			throw new ExpenseDaoException("not able to add in dao",e);
		}
	}

	public boolean deleteExpense(Expense expense) throws ExpenseDaoException {
		try {
			this.sessionFactory.getCurrentSession().delete(expense);
			return true;
		} catch (HibernateException e) {
			throw new ExpenseDaoException("not able to delete in dao",e);
		}
	}

	public Expense updateExpense(Expense expense) throws ExpenseDaoException {
		try {
			this.sessionFactory.getCurrentSession().update(expense);
			return expense;
		} catch (HibernateException e) {
			throw new ExpenseDaoException("not able to update in dao",e);
		}
	}

	public Expense getExpenseById(int id) throws ExpenseDaoException {
		try {
			return this.sessionFactory.getCurrentSession().get(Expense.class, new Integer(id));
		} catch (HibernateException e) {
			throw new ExpenseDaoException("not able to get in dao",e);
		}
	}

	public List<Expense> getAllExpenses(int userId) throws ExpenseDaoException {
		List<Expense> expenses = new ArrayList<Expense>();
		try {
			User user= userService.getUserById(userId);
			expenses  = (List<Expense>)this.sessionFactory.getCurrentSession().createQuery("from Expense m where m.user = :user").setParameter("user", user).list();
			System.out.println(expenses);
			return expenses;
		} catch (HibernateException e) {
			throw new ExpenseDaoException("not able to get in dao",e);
		}
	}

}
