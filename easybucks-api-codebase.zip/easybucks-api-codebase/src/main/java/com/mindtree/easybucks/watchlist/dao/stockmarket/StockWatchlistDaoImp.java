package com.mindtree.easybucks.watchlist.dao.stockmarket;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.entities.StockWatchlist;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

@Repository
@Transactional("transactionManager")
public class StockWatchlistDaoImp implements StockWatchlistDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean addToStockWatchlist(User user, Stocks stock) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(StockWatchlist.class, new Integer(user.getUserId()))!=null)
		{	
			if(getStockWatchlistByUser(user).contains(stock)){
			return false;
			}
		}
		else{
			StockWatchlist stockWatchList1 = new StockWatchlist() ;
			stockWatchList1.setUser(user);
			this.sessionFactory.getCurrentSession().save(stockWatchList1) ;
		}
		try {
			List<Stocks> stocks = getStockWatchlistByUser(user);
			Set<Stocks> stocks1 = new HashSet<Stocks>();
			for (Stocks m : stocks) {
				stocks1.add(m);
			}
			stocks1.add(stock);
			StockWatchlist stockWatchlist = (StockWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from StockWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			stockWatchlist.setStockList(stocks1);
			sessionFactory.getCurrentSession().save(stockWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}

	}

	@Transactional
	public boolean deleteFromStockWatchlist(User user, Stocks stock) throws WatchlistDaoException {
		if(this.sessionFactory.getCurrentSession().get(StockWatchlist.class, new Integer(user.getUserId()))==null){
			return true ;
		}
		try {
			List<Stocks> stocks = getStockWatchlistByUser(user);
			Set<Stocks> stocks1 = new HashSet<Stocks>();
			for (Stocks m : stocks) {
				stocks1.add(m);
			}
			stocks1.remove(stock);
			StockWatchlist stockWatchlist = (StockWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from StockWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			stockWatchlist.setStockList(stocks1);
			sessionFactory.getCurrentSession().save(stockWatchlist);
			return true;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}

	}

	public List<Stocks> getStockWatchlistByUser(User user) throws WatchlistDaoException {
		try {
			StockWatchlist stockWatchlist = (StockWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from StockWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			Set<Stocks> stocks = stockWatchlist.getStockList();
			List<Stocks> stocks1 = new ArrayList<Stocks>();
			for (Stocks s : stocks) {
				stocks1.add(s);
			}
			return stocks1;
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

	public Set<Stocks> getStockWatchlistByUser1(User user) throws WatchlistDaoException {
		try {
			StockWatchlist stockWatchlist = (StockWatchlist) this.sessionFactory.getCurrentSession()
					.createQuery("from StockWatchlist m where m.user = :user").setParameter("user", user).list().get(0);
			return stockWatchlist.getStockList();
		} catch (Exception e) {
			throw new WatchlistDaoException("No data avaliable", e);
		}
	}

}
