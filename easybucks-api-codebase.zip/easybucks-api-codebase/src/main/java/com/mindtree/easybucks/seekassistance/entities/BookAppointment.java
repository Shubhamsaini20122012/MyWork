package com.mindtree.easybucks.seekassistance.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book_appointment")
public class BookAppointment 
{
	@Id
	@Column(name="book_appointment_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int bookAppointmentId;
	
	@Column(name="investor_id")
	private int investorId;
	
	@Column(name="advisor_id")
	private int advisorId;
	
	@Column(name="reason")
	private String reason;
	
	@Column(name="appointment_date")
	private String appointmentDate;
	
	@Column(name="place")
	private String place;
	
	@Column(name="status")
	private String status;
	
	

	public BookAppointment() {
		super();
		
	}

	@Override
	public String toString() {
		return "BookAppointment [bookAppointmentId=" + bookAppointmentId + ", investor=" + investorId + ", advisor="
				+ advisorId + ", reason=" + reason + ", appointmentDate=" + appointmentDate + ", place=" + place
				+ ", status=" + status + "]";
	}

	public int getBookAppointmentId() {
		return bookAppointmentId;
	}

	public void setBookAppointmentId(int bookAppointmentId) {
		this.bookAppointmentId = bookAppointmentId;
	}

	public int getInvestorId() {
		return investorId;
	}

	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}

	public int getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
	
}
