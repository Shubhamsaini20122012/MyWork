package com.mindtree.easybucks.products.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.dao.StocksDao;
import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.StocksService;

@Service
public class StocksServiceImpl implements StocksService {

	@Autowired
	private StocksDao stocksDao ;
	
	public void setStocksDao(StocksDao stocksDao) {
		this.stocksDao = stocksDao;
	}

	public String addStocks(Stocks stocks) throws ProductsServiceException {
		
		try {
			return this.stocksDao.addStocks(stocks);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to add Stocks from Service",e) ;
		}
	}

	public List<Stocks> getAllStocks() throws ProductsServiceException {
		try {
			return this.stocksDao.getAllStocks();
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch Stocks List from Service",e) ;
		}
	}
	
	public Stocks getStocks(int id) throws ProductsServiceException {
		try {
			return this.stocksDao.getStocks(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch Stocks from Service",e) ;
		}
	}
	
	public String deleteStocks(int id) throws ProductsServiceException {
		try {
			return this.stocksDao.deleteStocks(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to delete Stocks from Service",e) ;
		}
	}
}
